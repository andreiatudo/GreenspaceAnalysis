# MainDataSet > 2025-09-06 6:37pm
https://universe.roboflow.com/andreiatudo/maindataset-bdoew

Provided by a Roboflow user
License: CC BY 4.0

